package com.h3c.core.api.sdk.signature;


import com.h3c.core.api.sdk.exception.SdkException;

public interface ISignerFactory {
    ISinger getSigner() throws SdkException;
}
