package com.h3c.core.api.sdk.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

import java.util.Date;

public class JwtSign {

    /**
     * Jwt签名
     * Using HS256 Algorithm
     *
     * @param accessKey A unique string identifying the credential.
     * @param secretKey Secret used to sign JWTs for the credential
     * @param timeToLiveSeconds Time to live in seconds
     * @return The value of Authorization header
     */
    public static String sign(String accessKey, String secretKey, Integer timeToLiveSeconds) {
        if (HttpCommonUtil.isEmpty(accessKey)) {
            throw new IllegalArgumentException("accessKey can not be empty");
        }
        if (HttpCommonUtil.isEmpty(secretKey)) {
            throw new IllegalArgumentException("secretKey can not be empty");
        }
        if (null == timeToLiveSeconds) {
            throw new IllegalArgumentException("timeToLiveSeconds can not be empty");
        }
        Date now = new Date();
        Date expire = new Date(now.getTime() + timeToLiveSeconds * 1000L);
        Algorithm algorithm = Algorithm.HMAC256(secretKey);
        return "Bearer " + JWT.create().withIssuer(accessKey).withIssuedAt(now).withExpiresAt(expire).sign(algorithm);
    }
}
