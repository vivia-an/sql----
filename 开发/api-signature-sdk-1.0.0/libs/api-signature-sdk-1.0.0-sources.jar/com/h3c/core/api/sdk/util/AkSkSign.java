package com.h3c.core.api.sdk.util;

import com.h3c.core.api.sdk.exception.SdkException;
import com.h3c.core.api.sdk.model.Request;
import com.h3c.core.api.sdk.signature.ISignerFactory;
import com.h3c.core.api.sdk.signature.ISinger;
import com.h3c.core.api.sdk.signature.SignerFactoryManager;
import org.apache.commons.codec.binary.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

public class AkSkSign {


    /**
     * AkSk签名
     * @return HTTP request headers with Authorization and Digest
     */
    public static Map<String, String> sign(Request r) {
        return sign(r.getEnforceHeaders(), r.getRequestHeaders(), r.getSignAlgorithm(), r.getAccessKey(),
                r.getSecretKey(), r.getRequestLine(), r.isValidateBody(), r.getBody());

    }

    /**
     * AkSk签名
     *
     * @param hmacHeaders A list of headers which the client should at least use for HTTP signature creation
     * @param httpHeaders HTTP request headers
     * @param algorithm A list of HMAC digest algorithms which the user wants to support.
     *                  Allowed values are hmac-sha1, hmac-sha256, hmac-sha384, and hmac-sha512
     * @param ak The username to use in the HMAC Signature verification
     * @param sk The secret to use in the HMAC Signature verification.
     * @param requestLine The HTTP request line (e.g. "GET /requests HTTP/1.1")
     * @param validateBody Set true to validate the request body
     * @param body The request body
     * @return HTTP request headers with Authorization and Digest
     */
    private static Map<String, String> sign(List<String> hmacHeaders, Map<String, String> httpHeaders, String algorithm,
                                           String ak, String sk, String requestLine, boolean validateBody,
                                            String body) {
        if (validateBody && null != body) {
            String digest = calculatingDigest(body);
            httpHeaders.put("Digest", digest);
            hmacHeaders.add("Digest");
        }
        String signingString = composeSigningString(hmacHeaders, httpHeaders, requestLine);
        String signature = hmac(algorithm, sk, signingString);
        StringBuilder authorization = new StringBuilder();
        append(authorization, "hmac username", ak);
        append(authorization, "algorithm", algorithm);
        StringBuilder hmacHeadersSB = new StringBuilder();
        for (int i = 0; i < hmacHeaders.size(); i++) {
            hmacHeadersSB.append(hmacHeaders.get(i));
            if(i < hmacHeaders.size() - 1) {
                hmacHeadersSB.append(" ");
            }
        }
        append(authorization, "headers", hmacHeadersSB.toString());
        append(authorization, "signature", signature);
        httpHeaders.put("Authorization", authorization.toString());
        return httpHeaders;
    }

    private static String calculatingDigest(String body) {
        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new SdkException(e);
        }
        byte[] hash = messageDigest.digest(body.getBytes(StandardCharsets.UTF_8));
        return "SHA-256=" + Base64.encodeBase64String(hash);
    }

    public static String composeSigningString(List<String> hmacHeaders, Map<String, String> httpHeaders, String requestLine) {
        StringBuilder signingSB = new StringBuilder();
        for (int i = 0; i < hmacHeaders.size(); i++) {
            String header = hmacHeaders.get(i);
            String value = httpHeaders.get(header);
            if (null == value) {
                if ("request-line".equals(header)) {
                    signingSB.append(requestLine);
                } else {
                    signingSB.append(header).append(":");
                }
            } else {
                signingSB.append(header).append(": ").append(value);
            }
            if (i < hmacHeaders.size() - 1) {
                signingSB.append("\n");
            }
        }
        return signingSB.toString();
    }

    public static String hmac(String algorithm, String sk, String signingString) {
        ISignerFactory signerFactory = SignerFactoryManager.findSignerFactory(algorithm);
        ISinger signer = signerFactory.getSigner();
        if (null == signer) {
            throw new SdkException("Oops!");
        }
        try {
            return signer.sign(signingString, sk);
        } catch (Exception e) {
            throw new SdkException(e);
        }
    }

    public static void append(StringBuilder sb, String key, String value) {
        if (sb.length() > 0) {
            sb.append(", ");
        }
        sb.append(key).append("=\"").append(value).append("\"");
    }
}
