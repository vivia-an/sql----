package com.h3c.core.api.sdk.exception;

public class SdkException extends RuntimeException {

    public SdkException(String message) {
        super(message);
    }

    public SdkException(Throwable cause) {
        super(cause);
    }

}
