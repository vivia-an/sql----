package com.h3c.core.api.sdk.signature;


import com.h3c.core.api.sdk.exception.SdkException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface ISinger {
    String sign(String strToSign, String secretKey) throws NoSuchAlgorithmException, InvalidKeyException , SdkException;
}
