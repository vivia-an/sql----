package com.h3c.core.api.sdk.model;

import java.util.*;

public class Request {
    private String signAlgorithm;
    private String accessKey;
    private String secretKey;
    private boolean validateBody;
    private List<String> enforceHeaders = new ArrayList<>();
    private Map<String, String> requestHeaders = new HashMap<>();
    private String requestLine;
    private String body;

    public String getSignAlgorithm() {
        return signAlgorithm;
    }

    public void setSignAlgorithm(String signAlgorithm) {
        this.signAlgorithm = signAlgorithm;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public boolean isValidateBody() {
        return validateBody;
    }

    public void setValidateBody(boolean validateBody) {
        this.validateBody = validateBody;
    }

    public List<String> getEnforceHeaders() {
        return enforceHeaders;
    }

    public void setEnforceHeaders(List<String> enforceHeaders) {
        this.enforceHeaders = enforceHeaders;
    }

    public void addEnforceHeader(String header) {
        if (null != header && !header.trim().isEmpty()) {
            this.enforceHeaders.add(header);
        }
    }

    public Map<String, String> getRequestHeaders() {
        return requestHeaders;
    }

    public void setRequestHeaders(Map<String, String> requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    public void addHeader(String name, String value) {
        if (null != name && !name.trim().isEmpty()) {
            this.requestHeaders.put(name, value);
        }
    }

    public String getRequestLine() {
        return requestLine;
    }

    public void setRequestLine(String requestLine) {
        this.requestLine = requestLine;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

}
